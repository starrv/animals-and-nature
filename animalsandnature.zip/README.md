This is a web application where people can make posts and share information about animals and nature.  This application was built using JavaScript, PHP, HTML, CSS, and Bootstrap.  This is a solo project.
# animals-and-nature
