<?php

  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;

  require_once "vendor/autoload.php";

  use Aws\SecretsManager\SecretsManagerClient; 
  use Aws\Exception\AwsException;

  function connect()
  {
    $server = "localhost";
    $username = "user1";
    $password = "aNXvw9dZ7y3kKE0w";
    $db = "animals_and_nature";

    $GLOBALS['conn'] = new mysqli($server, $username, $password, $db);

    //check connection
    if($GLOBALS['conn']->connect_error)
    {
      $GLOBALS['conn']=false;
      generateErrorMessage();
      return false;
    }
    return true;
  }


  function sendEmail($name, $email,$subject, $body, $altBody)
  {
    try
    {
      $mail = new PHPMailer(true);
      $mail->CharSet = 'UTF-8';
      $mail->Encoding = 'base64';

      //Enable SMTP debugging.
      $mail->SMTPDebug = 3;

      //Set PHPMailer to use SMTP.
      $mail->isSMTP();

      //Set SMTP host name
      $mail->Host = "smtp.gmail.com";

      //Set this to true if SMTP host requires authentication to send email
      $mail->SMTPAuth = true;

      //Provide username and password
      $mail->Username = "valesta36";
      $mail->Password = "w8ew8fw9w0twr";

      //If SMTP requires TLS encryption then set it
      $mail->SMTPSecure = "tls";

      //Set TCP port to connect to
      $mail->Port = 587;

      $mail->From = "no-reply@animalsandnature.net";
      $mail->FromName = "Animals and Nature";

      $mail->addAddress($email, $name);
      $mail->isHTML(true);
      $mail->Subject = $subject;


      $mail->Body = $body;
      $mail->AltBody = $altBody;
      $mail->send();

      return true;
    }
    catch (Exception $e)
    {
      echo $mail->ErrorInfo;
      return false;
    }
  }

  function getDBCredentials()
  {
    $client = new SecretsManagerClient([
      'profile' => 'default',
      'version' => '2017-10-17',
      'region' => 'us-east-1',
    ]);

    $secretName = 'animals-and-nature-db-credentials';

    try {
        $result = $client->getSecretValue([
            'SecretId' => $secretName,
        ]);

    } catch (AwsException $e) {
        $error = $e->getAwsErrorCode();
        if ($error == 'DecryptionFailureException') {
            // Secrets Manager can't decrypt the protected secret text using the provided AWS KMS key.
            // Handle the exception here, and/or rethrow as needed.
            //throw $e;
            echo "Error: DecryptionFailureException";
        }
        if ($error == 'InternalServiceErrorException') {
            // An error occurred on the server side.
            // Handle the exception here, and/or rethrow as needed.
            //throw $e;
            echo "Error: InternalServiceErrorException";
        }
        if ($error == 'InvalidParameterException') {
            // You provided an invalid value for a parameter.
            // Handle the exception here, and/or rethrow as needed.
            //throw $e;
            echo "Error: InvalidParameterException";
        }
        if ($error == 'InvalidRequestException') {
            // You provided a parameter value that is not valid for the current state of the resource.
            // Handle the exception here, and/or rethrow as needed.
            //throw $e;
            echo "Error: InvalidRequestException";
        }
        if ($error == 'ResourceNotFoundException') {
            // We can't find the resource that you asked for.
            // Handle the exception here, and/or rethrow as needed.
            //throw $e;
            echo "Error: ResourceNotFoundException";
        }
    }
    // Decrypts secret using the associated KMS CMK.
    // Depending on whether the secret is a string or binary, one of these fields will be populated.
    if (isset($result['SecretString'])) {
        $secret = $result['SecretString'];
    } else {
        $secret = base64_decode($result['SecretBinary']);
    }

    // Your code goes here; 
    $secret_data=str_replace("{","",$secret);
    $secret_data=str_replace("}","",$secret_data);
    $secret_data=str_replace('"','',$secret_data);
    $secret_data=explode(",", $secret_data);
    $secret_array=array();
    $key_value_pair="";
    for($i=0; $i<count($secret_data); $i++)
    {
      $key_value_pair=explode(":",$secret_data[$i]);
      $secret_array[$key_value_pair[0]]=$key_value_pair[1];
    }
    return $secret_array;
  }

?>