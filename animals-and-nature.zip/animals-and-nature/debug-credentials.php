<?php

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

	require_once "vendor/autoload.php";

	const SITE_URL="http://localhost/animals-and-nature";
	const DOMAIN_URL="localhost";
	const HTTP_SECURE_ATTRIB=1;
 	const HTTP_HTTP_ATTRIB=1;
	const WEBMASTER_EMAIL="webmaster@animalsandnature.net";

	function connect()
	{
		$server = "localhost";
		$username = "user-1";
		$password = "12345678";
		$db = "animals_and_nature";

		$GLOBALS['conn'] = new mysqli($server, $username, $password, $db);

		//check connection
		if($GLOBALS['conn']->connect_error)
		{
		  $GLOBALS['conn']=false;
		  generateErrorMessage();
		  return false;
		}
		return true;
	}

  	function sendEmail($name, $email,$subject, $body, $altBody,$attachment=null,$attachment_name="")
	{
		try
		{
		  $mail = new PHPMailer(true);
		  $mail->CharSet = 'UTF-8';
		  $mail->Encoding = 'base64';

		  //Set PHPMailer to use SMTP.
		  $mail->isSMTP();

		  //Set SMTP host name
		  $mail->Host = "email-smtp.us-east-1.amazonaws.com";

		  //Set this to true if SMTP host requires authentication to send email
		  $mail->SMTPAuth = true;

		  //Provide username and password
		  $mail->Username = "AKIAYG64TEQH5Y6EHTFF";
		  $mail->Password = "BHVKPYYgp+CwwCaDFcr/WUby/n1kcYcD4gWoUx0a+kJK";

		  //If SMTP requires TLS encryption then set it
		  $mail->SMTPSecure = "tls";

		  //Set TCP port to connect to
		  $mail->Port = 587;

		  $mail->From = "no-reply@animalsandnature.net";
		  $mail->FromName = "Animals and Nature Message Board";

		  $mail->addAddress($email, $name);
		  $mail->isHTML(true);
		  $mail->Subject = $subject;


		  $mail->Body = $body;
		  $mail->AltBody = $altBody;
		  if(!empty($attachment) && !empty($attachment_name)){
			$mail->AddAttachment($attachment,$attachment_name);
		  }
		  

		  $mail->send();

		  return true;
		}
		catch (Exception $e)
		{
		  echo $mail->ErrorInfo;
		  return false;
		}
	}

?>